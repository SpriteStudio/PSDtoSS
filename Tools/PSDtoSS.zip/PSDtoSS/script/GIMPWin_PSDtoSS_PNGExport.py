#!/usr/bin/python
# coding: UTF-8
from gimpfu import *
import os.path
import gimpfu
import re

def python_psdtoss_export(img, drawable):
  
  is_err = 0
  #出力ディレクトリ、ファイル名の作成
  start = img.filename.rfind('\\')
  end = img.filename.rfind('.')
  dst = img.filename[0:start]
  outname = img.filename[start + 1:end]
  dirname = "\\" + "ssceconv_" + outname
  
  #ディレクトリの作成
  dst = dst + dirname
  if os.path.isdir(dst) == False :
    os.mkdir(dst)
  
  #レイヤー名のチェック
  for layer in img.layers:
    if layer.name.find('@') == -1:
      namestr = layer.name
      #禁則文字チェック
      if "#" in namestr:
        is_err = 1
        str = "禁則文字のレイヤーがあります：%s\r\nレイヤー名を確認してください。\r\n出力を中断します。" % layer.name
        pdb.gimp_message(str)
      if "." in namestr:
        is_err = 1
        str = "禁則文字のレイヤーがあります：%s\r\nレイヤー名を確認してください。\r\n出力を中断します。" % layer.name
        pdb.gimp_message(str)
      
      #全て半角英数字か？
      #Pythonの正規表現で、渡された文字列が全て半角英数字かチェックします。(UTF-8向け) 
      #Python 正規表現 半角英数字 UTF8
      regexp = re.compile(r'^[\x20-\x7e]+$')
      result = regexp.search(layer.name)
      if result == None :
        is_err = 1
        str = "全角文字のレイヤーがあります：%s\r\nレイヤー名を確認してください。\r\n出力を中断します。" % layer.name
        pdb.gimp_message(str)
  
  if is_err == 0 :
    # レイヤーをpngで出力
    for layer in img.layers :
      if layer.name.find('@') == -1:
        path="%s/%s.png" % (dst, layer.name)
        #gimpfu.pdb.gimp_message(path)
        gimpfu.pdb.file_png_save_defaults(img, layer, path, path)
    
    # レイヤー名をテキストに出力
    fname = "%s/%s.txt" % (dst,outname)
    output_path = os.path.join(dst, fname)
    
    outstr = "";
    for layer in img.layers :
      if layer.name.find('@') == -1:
        outstr = outstr + "%s.png#" % (layer.name)
    
    fw = open(output_path, 'w')
    fw.write(outstr)
    fw.close()
    
    pdb.gimp_message("PSDtoSS用pngファイルを出力しました。\r\n出力フォルダのテキストファイルを指定してコンバートしてください。\r\n%s" % (output_path))


gimpfu.register(
  # name
  "PSDtoSS-Export",
  # blurb
  "PSDtoSS Export",
  # help
  "Sprite Studio5用のツールPSDtoSSで使用するpngファイル、テキストファイルを出力します",
  # author
  "Web Technology Corp.",
  # copyright
  "Web Technology Corp.",
  # date
  "2015.07.29",
  # menupath
  "<Image>/SpriteStudio5/PSDtoSSExport",
  # imagetypes
  "RGB*",
  # params
  [],
  # results
  [],
  # function
  python_psdtoss_export)

gimpfu.main()
